import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Star, Users, Sparkles, Split, CreditCard, XCircle, CheckCircle2, AlertTriangle } from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface GranPlusModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  elderId: number;
  elderName: string;
  isAdmin?: boolean;
}

const FEATURES = [
  "Wellbeing mood check-ins after each visit",
  "Visit photos & notes",
  "Multiple gran profiles",
  "Custom alert threshold",
  "Full visit history & insights",
  "Care notes visible to all visitors",
];

export function GranPlusModal({ open, onOpenChange, elderId, elderName, isAdmin = false }: GranPlusModalProps) {
  const utils = trpc.useUtils();
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const { user } = useAuth();

  const { data: subStatus } = trpc.subscription.status.useQuery(
    { elderId },
    { enabled: open }
  );

  const toggleContribution = trpc.subscription.toggleContribution.useMutation({
    onSuccess: () => {
      const wasContributing = subStatus?.amIContributing;
      toast.success(wasContributing ? "You've left the split." : "You've joined the split! 💚");
      utils.subscription.status.invalidate({ elderId });
    },
    onError: (e) => toast.error(e.message),
  });

  const requestCancellation = trpc.subscription.requestCancellation.useMutation({
    onSuccess: () => {
      toast.success("Cancellation request sent. Gran+ stays active until confirmed.");
      utils.subscription.status.invalidate({ elderId });
      utils.elders.get.invalidate({ elderId });
      setCancelDialogOpen(false);
    },
    onError: (e) => toast.error(e.message),
  });

  const handleSubscribe = () => {
    if (!termsAccepted) {
      toast.error("Please accept the terms before subscribing.");
      return;
    }
    if (!user) {
      toast.error("Please sign in to subscribe.");
      return;
    }
    const params = new URLSearchParams({
      elderId: String(elderId),
      userId: String(user.id),
      email: user.email ?? "",
      name: user.name ?? "GranWatch User",
      origin: window.location.origin,
      contributors: String(Math.max(contributorCount, 1)),
    });
    window.location.href = `/api/payfast/checkout?${params.toString()}`;
  };

  // Join split: existing Gran+ subscriber, new contributor pays their share
  const handleJoinSplit = () => {
    if (!user) {
      toast.error("Please sign in first.");
      return;
    }
    // First register as contributor in DB, then go to Payfast for their share
    toggleContribution.mutate({ elderId }, {
      onSuccess: () => {
        const newCount = (subStatus?.contributorCount ?? 1) + 1;
        const params = new URLSearchParams({
          elderId: String(elderId),
          userId: String(user.id),
          email: user.email ?? "",
          name: user.name ?? "GranWatch User",
          origin: window.location.origin,
          contributors: String(newCount),
        });
        window.location.href = `/api/payfast/checkout?${params.toString()}`;
      },
    });
  };

  const perPersonRands = subStatus
    ? (subStatus.perPersonCost / 100).toFixed(2)
    : "27.00";
  const totalRands = "27.00";
  const contributorCount = subStatus?.contributorCount ?? 1;
  const isPaid = subStatus?.isPaid ?? false;
  const cancellationPending = !!subStatus?.cancellationRequestedAt;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-sm mx-auto max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              Gran+ for {elderName}
            </DialogTitle>
          </DialogHeader>

          {/* Price */}
          <div className="bg-primary/10 rounded-xl p-4 text-center mb-2">
            <div className="text-3xl font-bold text-primary">R{totalRands}</div>
            <div className="text-sm text-muted-foreground">per month</div>
            {subStatus && subStatus.contributorCount > 1 && (
              <div className="mt-2 text-sm font-semibold text-primary">
                = R{perPersonRands} each with {subStatus.contributorCount} contributors
              </div>
            )}
          </div>

          {/* Active status badge */}
          {isPaid && (
            <div className="flex items-center justify-center gap-2 mb-2">
              {cancellationPending ? (
                <div className="inline-flex items-center gap-2 bg-amber-100 text-amber-700 px-4 py-2 rounded-full text-sm font-semibold">
                  <AlertTriangle className="w-4 h-4" />
                  Cancellation requested
                </div>
              ) : (
                <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-semibold">
                  <CheckCircle2 className="w-4 h-4" />
                  Gran+ is active
                </div>
              )}
            </div>
          )}

          {/* Split payment section — always visible */}
          <div className="bg-card border rounded-xl p-4 mb-4">
            <div className="flex items-center gap-2 mb-3">
              <Split className="w-4 h-4 text-primary" />
              <span className="font-semibold text-sm">Split with the family</span>
            </div>
            <p className="text-xs text-muted-foreground mb-3">
              The more family members who chip in, the cheaper it gets for everyone.
              {!isPaid && subStatus?.contributorCount === 0 && " Be the first to contribute!"}
            </p>

            {subStatus && subStatus.contributors.length > 0 && (
              <div className="space-y-1.5 mb-3">
                {subStatus.contributors.map((c: any) => (
                  <div key={c.id} className="flex items-center justify-between text-sm">
                    <span className="text-foreground">{c.isMe ? "You" : c.userName}</span>
                    <span className="text-muted-foreground">R{perPersonRands}/mo</span>
                  </div>
                ))}
              </div>
            )}

            {/* Split actions depend on whether Gran+ is active */}
            {isPaid ? (
              subStatus?.amIContributing ? (
                // Already contributing — offer to leave split
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full text-muted-foreground"
                  onClick={() => toggleContribution.mutate({ elderId })}
                  disabled={toggleContribution.isPending}
                >
                  <Users className="w-4 h-4 mr-2" />
                  {toggleContribution.isPending ? "Updating..." : "Leave the split"}
                </Button>
              ) : (
                // Not yet contributing — offer to join split with Payfast
                <Button
                  variant="default"
                  size="sm"
                  className="w-full"
                  onClick={handleJoinSplit}
                  disabled={toggleContribution.isPending}
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  {toggleContribution.isPending ? "Redirecting..." : `Join split — R${((2700 / (contributorCount + 1)) / 100).toFixed(2)}/mo`}
                </Button>
              )
            ) : (
              // Gran+ not yet active — pre-subscribe toggle
              <Button
                variant={subStatus?.amIContributing ? "outline" : "default"}
                size="sm"
                className="w-full"
                onClick={() => toggleContribution.mutate({ elderId })}
                disabled={toggleContribution.isPending}
              >
                <Users className="w-4 h-4 mr-2" />
                {subStatus?.amIContributing ? "Remove my contribution" : "Add my contribution"}
              </Button>
            )}
          </div>

          {/* Features list */}
          <div className="mb-4">
            <p className="text-sm font-semibold text-foreground mb-2">What you unlock:</p>
            <ul className="space-y-1.5">
              {FEATURES.map(f => (
                <li key={f} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <Star className="w-3.5 h-3.5 text-primary flex-shrink-0 mt-0.5 fill-primary" />
                  {f}
                </li>
              ))}
            </ul>
          </div>

          {/* Bottom action area */}
          <div className="space-y-3">
            {!isPaid ? (
              <>
                {/* Terms checkbox */}
                <div className="flex items-start gap-3 bg-muted/50 rounded-xl p-3">
                  <Checkbox
                    id="terms"
                    checked={termsAccepted}
                    onCheckedChange={(v) => setTermsAccepted(v === true)}
                    className="mt-0.5 flex-shrink-0"
                  />
                  <label htmlFor="terms" className="text-xs text-muted-foreground leading-relaxed cursor-pointer">
                    I understand that Gran+ subscriptions are <strong className="text-foreground">non-refundable</strong>. Payments are charged monthly and you may cancel at any time to stop future charges. No refunds are issued for partial months.
                  </label>
                </div>

                <Button
                  className="w-full h-12 font-semibold gap-2"
                  onClick={handleSubscribe}
                  disabled={!termsAccepted}
                >
                  <CreditCard className="w-4 h-4" />
                  Subscribe — R{perPersonRands}/mo
                </Button>
                <p className="text-center text-xs text-muted-foreground">
                  Secure payment via Payfast. Cancel anytime to stop future charges.
                  {contributorCount > 1 && ` Your share: R${perPersonRands}/month (${contributorCount} contributors).`}
                </p>
              </>
            ) : (
              <>
                {/* Cancellation — admin only */}
                {isAdmin && !cancellationPending && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full border-destructive/40 text-destructive hover:bg-destructive/5"
                    onClick={() => setCancelDialogOpen(true)}
                  >
                    <XCircle className="w-4 h-4 mr-2" />
                    Cancel Gran+
                  </Button>
                )}
                {cancellationPending && (
                  <p className="text-xs text-amber-600 text-center px-2">
                    Cancellation has been requested. Gran+ will stay active until the owner processes it. No further charges will be made once cancelled.
                  </p>
                )}
                {!isAdmin && (
                  <p className="text-xs text-muted-foreground text-center px-2">
                    Only the profile admin can cancel Gran+. Contact your family admin if you need to cancel.
                  </p>
                )}
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Cancellation confirmation dialog */}
      <AlertDialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              Cancel Gran+ for {elderName}?
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-2">
              <span className="block">
                This will send a cancellation request to the GranWatch owner, who will cancel the recurring payment in Payfast.
              </span>
              <span className="block font-medium text-foreground">
                Gran+ features remain active until the cancellation is confirmed. No refund will be issued for the current billing period.
              </span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Keep Gran+</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              onClick={() => requestCancellation.mutate({ elderId })}
              disabled={requestCancellation.isPending}
            >
              {requestCancellation.isPending ? "Sending request..." : "Yes, request cancellation"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
